for i in `cat list.correct`;do grep -i  "$i" tab_sep_mega_file2 >>foxl2_DN_DS;done

