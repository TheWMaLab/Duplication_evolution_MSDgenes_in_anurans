for i in `cat modi.list`;do grep -i  "$i" tab_sep_mega_file2 >>SOX3_DN_DS;done

